using Microsoft.AspNetCore.Mvc;
using TaskManagerApi.Api.Services.Interfaces;

namespace TaskManagerApi.Api.Controllers;

[ApiController]
[Route("api/[controller]")]

public class TaskController : ControllerBase
{
      private readonly ITaskService _taskService;
      public TaskController(ITaskService taskService)
      {
            _taskService = taskService;
      }

      // GET/api/tasks
      [HttpGet]
      public IActionResult GetAll()
      {
            return Ok(_taskService.GetAllTasks());
      }

      // GET/api/tasks/{id}
      [HttpGet("{id}")]
      public IActionResult GetById(int id)
      {
            var task = _taskService.GetTaskById(id);
            if(task is null) return NotFound();
            return Ok(task);
      }

      // POST/api/tasks
      [HttpPost]
      public IActionResult Create([FromBody] TaskItem task)
      {
            var created = _taskService.CreateTask(task.Title);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
      }


}