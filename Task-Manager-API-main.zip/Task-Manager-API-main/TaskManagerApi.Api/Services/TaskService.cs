using TaskManagerApi.Api.Repositories.Interfaces;
using TaskManagerApi.Api.Services.Interfaces;

namespace TaskManagerApi.Api.Services;

public class TaskService : ITaskService
{
    private readonly ITaskRepository _taskRepository;
    public TaskService (ITaskRepository taskRepository)
    {
        _taskRepository = taskRepository;
    }
    public List <TaskItem> GetAllTasks() => _taskRepository.GetAll();
    public TaskItem? GetTaskById(int id) => _taskRepository.GetById(id);
    public TaskItem CreateTask(string title)
      {
            var task= new TaskItem
            {
                  Title = title,
                  IsCompleted = false
                  CreatedAt = DateTime.UtcNow
            };
            return _taskRepository.Add(task);
      }

}
